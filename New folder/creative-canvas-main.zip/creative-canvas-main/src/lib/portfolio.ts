import marketplace from "@/assets/marketplace.png.asset.json";
import telecom from "@/assets/telecom.jpg.asset.json";
import nutribuddy from "@/assets/nutribuddy.jpg.asset.json";
import finscope from "@/assets/finscope.jpg.asset.json";

export const profile = {
  email: "asifyousaf14@gmail.com",
  github: "https://github.com/Asifyousaf",
  linkedin: "https://www.linkedin.com/in/asif-khan-177888278/",
  resume: "https://github.com/Asifyousaf/MyPortfolio.github.io/raw/main/Asif%20CV.pdf",
};

export const projects = [
  {
    slug: "alnuaimi-group", number: "01", title: "Al Nuaimi Group", category: "WEB + MOBILE / MARKETPLACE", short: "One marketplace. Many possibilities.",
    image: marketplace.url, alt: "Al Nuaimi Group marketplace with premium number plates and Dubai skyline",
    stack: ["React", "React Native", "Expo", "TypeScript", "Vite", "React Native Skia"],
    description: "A cross-platform marketplace connecting buyers and sellers of premium UAE number plates, VIP mobile numbers, vehicles and real estate.",
    problem: "Bring very different asset categories into a coherent marketplace that works on both the web and mobile.",
    contributions: ["Built an interactive Draw My Plate tool using React Native Skia and Canvas for real-time plate visualization.", "Engineered cross-platform push notifications for guests and authenticated users.", "Developed a shared web and mobile experience with React, React Native and TypeScript."],
    live: "https://www.alnuaimigroup.ae/", source: "", flow: ["Discover assets", "Explore listings", "Visualize plates", "Connect buyers & sellers"],
  },
  {
    slug: "telecom-ai", number: "02", title: "Telecom AI Assistant", category: "APPLIED AI / CUSTOMER SUPPORT", short: "Complex requests. Clear answers.",
    image: telecom.url, alt: "Telecom AI Assistant asking a customer for identification to help with billing",
    stack: ["Python", "FastAPI", "Google Gemini", "LangChain"],
    description: "An AI-powered customer support assistant for telecom billing, usage and service inquiries, built around natural-language understanding.",
    problem: "Help customers navigate account-specific telecom questions while retrieving information securely.",
    contributions: ["Developed an end-to-end AI chatbot for telecom customer support.", "Implemented secure customer identification and data retrieval.", "Integrated language-model responses with a Python and FastAPI application."],
    live: "", source: "", flow: ["Customer request", "Identify customer", "Retrieve account data", "Generate response"],
  },
  {
    slug: "nutribuddy", number: "03", title: "NutriBuddy", category: "FULL-STACK / AI WELLNESS", short: "A healthier everyday, intelligently.",
    image: nutribuddy.url, alt: "NutriBuddy fitness and nutrition application interface",
    stack: ["React", "TypeScript", "Tailwind CSS", "Supabase", "Google Gemini"],
    description: "A full-stack fitness and nutrition application with personalized guidance and an AI wellness companion.",
    problem: "Make workout and nutrition guidance accessible through a connected, personalized web experience.",
    contributions: ["Designed and built a full-stack wellness web application.", "Integrated a Gemini-powered chatbot for workout and recipe recommendations."],
    live: "https://nutribuddy.vercel.app/", source: "https://github.com/Asifyousaf/Nutribuddy", flow: ["Wellness goals", "Personalized guidance", "AI recommendations", "Daily progress"],
  },
  {
    slug: "finscope", number: "04", title: "FinScope", category: "WEB / REAL-TIME DATA", short: "A clearer view of the markets.",
    image: finscope.url, alt: "FinScope financial dashboard with market data and charts",
    stack: ["JavaScript", "HTML5", "Tailwind CSS", "Chart.js", "Twelve Data API"],
    description: "A real-time financial dashboard bringing market data, crypto tracking and currency exchange insights into one interface.",
    problem: "Turn disparate market data sources into a readable, multi-section financial dashboard.",
    contributions: ["Developed a fully functional multi-section financial dashboard.", "Integrated real-time stock and ETF data using Twelve Data and FMP APIs."],
    live: "https://finscope-one.vercel.app/", source: "https://github.com/Asifyousaf/FinScope", flow: ["Market APIs", "Data integration", "Chart visualization", "Financial insights"],
  },
];

export const otherWork = [
  { title: "Masat Al Nahar", category: "Corporate web experience", url: "https://www.masatalnahar.com/" },
  { title: "Cybertronic", category: "Full-stack e-commerce", url: "https://cybertronicbot.com/" },
  { title: "Fix My Ride", category: "Android / Kotlin / Firebase", url: "https://www.figma.com/design/1d641mijroI1sBszp7QlSr/High-fi---Fix-My-Ride" },
  { title: "TIME Magazine", category: "Editorial web development", url: "https://asifyousaf.github.io/Magazine.github.io/" },
];

export const stages = [
  { title: "Idea", label: "01 / UNDERSTAND", heading: "Start with the real problem.", description: "A marketplace, a support request, a wellness goal. The product begins with the person who needs it.", tools: "Product thinking · User journeys · Interface design", example: "Al Nuaimi Group: connecting premium-asset buyers and sellers." },
  { title: "Architecture", label: "02 / STRUCTURE", heading: "Make the pieces work together.", description: "Connect frontend experiences to APIs, data and services. Build a foundation that can support both web and mobile.", tools: "API design · Database design · Cross-platform systems", example: "Al Nuaimi Group: React on the web, React Native on mobile." },
  { title: "Engineering", label: "03 / BUILD", heading: "Turn the system into a product.", description: "Readable interfaces, secure backend connections and thoughtful interactions. Every detail has a job to do.", tools: "React · TypeScript · React Native · Python · FastAPI", example: "Draw My Plate: real-time visualization with React Native Skia." },
  { title: "Intelligence", label: "04 / AUGMENT", heading: "Intelligence with a purpose.", description: "Integrate language models where they make a real difference: understanding requests, generating useful responses and personalized recommendations.", tools: "Google Gemini · LangChain · LLM integrations", example: "Telecom AI: customer identification, account retrieval and natural-language responses." },
  { title: "Deployment", label: "05 / DELIVER", heading: "Ship something people can use.", description: "Bring the frontend, backend and data together in a working application. Production is part of the process, not an afterthought.", tools: "Vite · Git · Vercel · Firebase · Supabase", example: "NutriBuddy and FinScope: deployed web applications." },
];